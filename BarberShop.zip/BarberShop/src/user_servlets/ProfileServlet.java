package user_servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.User;
import classes.controllers.UserDBController;

@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/pages/profile.jsp";
        Cookie[] cookies = request.getCookies();
        String cookieName = "userName";
        Cookie cookie1 = null;
        String cookieLogin = "login";
        Cookie cookie2 = null;
        if(cookies !=null) {
            for(Cookie c: cookies) {
                if(cookieName.equals(c.getName())) {
                    cookie1 = c;
                    break;
                }
            }
            for(Cookie c: cookies) {
                if(cookieLogin.equals(c.getName())) {
                    cookie2 = c;
                    break;
                }
            }
        }
        User user = null;
//        System.out.println(cookie2);
        try { 
        	user = UserDBController.getUserByLogin(cookie2.getValue());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println(user.getLogin());

     	request.setAttribute("user", user);
        request.setAttribute("userName", cookie1.getValue());
        ServletContext servletContext = getServletContext();
        RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
        requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
