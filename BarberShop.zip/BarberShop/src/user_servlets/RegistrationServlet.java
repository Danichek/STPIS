package user_servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.User;
import classes.controllers.UserDBController;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String errorMessage = "";
       
   protected void doGet(HttpServletRequest request, HttpServletResponse response) 
		   throws ServletException, IOException {
	   String path = "/pages/registrationPage.jsp";
	   request.setAttribute("errorMessage", errorMessage);
       ServletContext servletContext = getServletContext();
       RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
       requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		boolean isExist = true;
		try {
			isExist = UserDBController.isUserPresent(request.getParameter("user_login"));
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		if(isExist) {
			errorMessage = "User with this login alredy exist!";
			doGet(request, response);
		}
		else {
			try {
				User user = new User(
						request.getParameter("user_login"),
						request.getParameter("password"),
						request.getParameter("name"),
						request.getParameter("surname"),
						request.getParameter("middlename"),
						request.getParameter("email") != null? request.getParameter("email") : "",
						request.getParameter("phone") != null? request.getParameter("phone") : ""
						);
				System.out.println(user.getLogin() + " " + user.getPassword());
				UserDBController.createUser(user);
				errorMessage = "";
				String path = request.getContextPath() + "/login";
		        response.sendRedirect(path);
				
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

}
