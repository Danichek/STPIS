package user_servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.controllers.UserDBController;

@WebServlet("/help")
public class HelpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/pages/loginPage.jsp";
        Cookie[] cookies = request.getCookies();
        String cookieName = "userName";
        Cookie cookie1 = null;
        String cookieLogin = "login";
        Cookie cookie2 = null;
        if(cookies !=null) {
            for(Cookie c: cookies) {
                if(cookieName.equals(c.getName())) {
                    cookie1 = c;
                    break;
                }  
            }
            for(Cookie c: cookies) {
                if(cookieLogin.equals(c.getName())) {
                    cookie2 = c;
                    break;
                }
            }
        }
        int userId = -1;
        try { 
        	userId = UserDBController.getUserIdByLogin(cookie2.getValue());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
        Cookie cookieUserId = new Cookie("userId",""+userId);
 

        response.addCookie(cookieUserId);
        request.setAttribute("userName", cookie1.getValue());
        ServletContext servletContext = getServletContext();
        RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
        requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
