package user_servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.User;
import classes.controllers.UserDBController;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String errorMessage = "";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
          Date dateNow = new Date();
          String dateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(dateNow);
		System.out.print(dateString);
        String path = "/pages/loginPage.jsp";
        request.setAttribute("errorMessage", errorMessage);
        ServletContext servletContext = getServletContext();
        RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
        requestDispatcher.forward(request, response);
    } 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
		User user = null;
		try {
			user = UserDBController.getUserByLogin(request.getParameter("user_login"));
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			errorMessage = "Wrong password";
			doGet(request, response);
		}
		if(user != null) {
			if(user.getPassword().equals(request.getParameter("password"))) {
				errorMessage = "";
				String path = request.getContextPath() + "/main";
				Cookie cookieName = new Cookie("userName", user.getUserName());
				Cookie cookieLogin = new Cookie("login", user.getLogin());
				response.addCookie(cookieName);
				response.addCookie(cookieLogin);
		        response.sendRedirect(path);
			}
			else {
				errorMessage = "Wrong password";
				doGet(request, response);
			}
		}
		
	}
}
