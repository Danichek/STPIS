package user_servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import classes.Masters;
import classes.Operations;
import classes.Orders;
import classes.User;
import classes.controllers.MastersDBController;
import classes.controllers.OptionsDBController;
import classes.controllers.OrdersDBController;
import classes.controllers.UserDBController;

@WebServlet("/order")
public class OrdersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String path = "/pages/createOrdersPage.jsp";
        Cookie[] cookies = request.getCookies();
        String cookieName = "userName";
        Cookie cookie1 = null;
        String cookieLogin = "login";
        Cookie cookie2 = null;
        if(cookies !=null) {
            for(Cookie c: cookies) {
                if(cookieName.equals(c.getName())) {
                    cookie1 = c;
                    break;
                }  
            }
            for(Cookie c: cookies) {
                if(cookieLogin.equals(c.getName())) {
                    cookie2 = c;
                    break;
                }
            }
        }
        
        int userId = -1;
        try { 
        	userId = UserDBController.getUserIdByLogin(cookie2.getValue());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
        System.out.println(userId);
        Cookie cookieUserId = new Cookie("userId",""+userId);
        List<Operations> operations= new ArrayList<>();
        operations = getOptionsList(operations);
        List<Masters> masters= new ArrayList<>();
        masters = getMastersList(masters);
        
        request.setAttribute("userName", cookie1.getValue());
        request.setAttribute("optionsList", operations);
        request.setAttribute("mastersList", masters);
        
        response.addCookie(cookieUserId);
        ServletContext servletContext = getServletContext();
        RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
        requestDispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String dateString = request.getParameter("orderDate");
		int mastersOptionsId = Integer.parseInt(request.getParameter("masters"));
		int orderOptionsId = Integer.parseInt(request.getParameter("options"));
		String userId = "";
        Cookie[] cookies = request.getCookies();
		if(cookies !=null) {
            for(Cookie c: cookies) {
                if("userId".equals(c.getName())) {
                    userId = c.getValue();
                    break;
                }  
            }
		}
		
		Orders order = new Orders(Integer.parseInt(userId), mastersOptionsId, orderOptionsId,dateString);
		OrdersDBController.createOrder(order);

		String path = request.getContextPath() + "/view_my_orders";
		response.sendRedirect(path);
	}
	
	private List<Masters> getMastersList(List<Masters> masters){
		List<Masters> mfromDB = MastersDBController.getMastersList();
		masters.add(new Masters(-1, "no selected", ""));
		for(Masters master: mfromDB) {
			masters.add(new Masters(master.getId(), master.getMasterName(), master.getMasterSurname()));
		}
        return masters;
	}
	
	private List<Operations> getOptionsList(List<Operations> operations){
		List<Operations> ofromDB = OptionsDBController.getOptionsList();
		operations.add(new Operations(-1, "no selected"));
		for(Operations operation: ofromDB) {
			operations.add(new Operations(operation.getOperation_id(), operation.getOperation_name()));
		}
        return operations;
	}

}
