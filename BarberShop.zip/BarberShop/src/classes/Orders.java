package classes;

import java.util.Date;

public class Orders {
	private int order_id;
	private int user_id;
	private int master_id;
	private int operation_id;
	private String orderDate;
	
	
	private String masterName;
	private String masterSurname;
	private String serviceName;
	
	
	public Orders() {}
	
	public Orders(int id, String masterName, String masterSurname, String serviceName, String date) {
		this.order_id = id;
		this.masterName = masterName;
		this.masterSurname = masterSurname;
		this.serviceName = serviceName;
		this.orderDate = date;
	}
	
	public Orders(int user_id, int master_id, int operation_id, String date) {
		this.master_id = master_id;
		this.user_id = user_id;
		this.operation_id = operation_id;
		this.orderDate = date;
	}
	public Orders(int id, int user_id, int master_id, int operation_id, String date) {
		this.master_id = master_id;
		this.user_id = user_id;
		this.order_id = id;
		this.operation_id = operation_id;
		this.orderDate = date;
	}
	
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public int getOperation_id() {
		return operation_id;
	}
	public void setOperation_id(int operation_id) {
		this.operation_id = operation_id;
	}
	public int getMaster_id() {
		return master_id;
	}
	public void setMaster_id(int master_id) {
		this.master_id = master_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public String getMasterName() {
		return masterName;
	}

	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}

	public String getMasterSurname() {
		return masterSurname;
	}

	public void setMasterSurname(String masterSurname) {
		this.masterSurname = masterSurname;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
