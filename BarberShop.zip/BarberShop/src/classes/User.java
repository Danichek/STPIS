package classes;

public class User {
	private static final long serialVersionUID = 1L;
	 
    private int id;
    private String login;
    private String password;
    private String userName;
    private String userSurname;
    private String userMiddlename;
    private String userPhone;
    private String userEmail;
    
    public User() {}
    public User(String l,String p, String un, String us, String um, String up, String ue) {
    	setLogin(l);
    	setPassword(p);
    	setUserName(un);
    	setUserSurname(us);
    	setUserMiddlename(um);
    	setUserPhone(up);
    	setUserEmail(ue);
    }
    
    public User(int id,String l,String p, String un, String us, String um, String up, String ue) {
    	setId(id);
    	setLogin(l);
    	setPassword(p);
    	setUserName(un);
    	setUserSurname(us);
    	setUserMiddlename(um);
    	setUserPhone(up);
    	setUserEmail(ue);
    }
    
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserSurname() {
		return userSurname;
	}
	public void setUserSurname(String userSurname) {
		this.userSurname = userSurname;
	}
	public String getUserMiddlename() {
		return userMiddlename;
	}
	public void setUserMiddlename(String userMiddlename) {
		this.userMiddlename = userMiddlename;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
}
