package classes;

public class Masters {
	private int masterId;
	private String masterName;
    private String masterSurname;
    private String masterMiddlename;
    
    public Masters() {}
    public Masters(String mn, String ms, String Mm) {
    	setMasterName(mn);
    	setMasterSurname(ms);
    	setMasterName(Mm);
    }
   
    
    public Masters(int id,String mn, String ms, String Mm) {
    	setId(id);
    	setMasterName(mn);
    	setMasterSurname(ms);
    	setMasterMiddlename(Mm);
    }
    
    public Masters(int id,String mn, String ms) {
    	setId(id);
    	setMasterName(mn);
    	setMasterSurname(ms);
    }
    
	public int getId() {
		return masterId;
	}
	public void setId(int id) {
		this.masterId = id;
	}

	public String getMasterName() {
		return masterName;
	}
	public void setMasterName(String name) {
		this.masterName = name;
	}
	public String getMasterSurname() {
		return masterSurname;
	}
	public void setMasterSurname(String surname) {
		this.masterSurname = surname;
	}
	public String getMasterMiddlename() {
		return masterMiddlename;
	}
	public void setMasterMiddlename(String middlename) {
		this.masterMiddlename = middlename;
	}
}
