package classes;

public class Operations {
	private int operation_id;
	private String operation_name;
	private long operation_price;
	
	public Operations() {
		
	}
	
	public Operations(int id, String name, long price) {
		this.setOperation_id(id);
		this.setOperation_name(name);
		this.setOperation_price(price);
	}
	
	public Operations(int id, String name) {
		this.setOperation_id(id);
		this.setOperation_name(name);
	}
	
	public Operations(String name, long price) {
		this.setOperation_name(name);
		this.setOperation_price(price);
	}

	public long getOperation_price() {
		return operation_price;
	}

	public void setOperation_price(long operation_price) {
		this.operation_price = operation_price;
	}

	public String getOperation_name() {
		return operation_name;
	}

	public void setOperation_name(String operation_name) {
		this.operation_name = operation_name;
	}

	public int getOperation_id() {
		return operation_id;
	}

	public void setOperation_id(int operation_id) {
		this.operation_id = operation_id;
	}
}
