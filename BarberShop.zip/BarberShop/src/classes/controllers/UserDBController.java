package classes.controllers;

import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;

import classes.DBConnector;
import classes.User;

public class UserDBController {
	static DBConnector conn = null;
	
	public static List<User> getAllUsers() throws SQLException {
		List<User> users = new ArrayList<>();
		conn = new DBConnector();
		users = conn.getAllUsers();
		return users;
	}
	
	public static int getUserIdByLogin(String login) throws SQLException {
		int userId = -1;
		conn = new DBConnector();
		userId = conn.getUserIdByLogin(login);
		return userId;
	}
	
	public static User getUserByLogin(String login) throws SQLException {
		User user = null;
		conn = new DBConnector();
		user = conn.getUserByLogin(login);
		return user;
	}
	
	public static boolean isUserPresent(String login)throws SQLException {
		boolean isUserPresentInDB = false;
		conn = new DBConnector();
		isUserPresentInDB = conn.isUserPresent(login);
		return isUserPresentInDB;
	}
	
	public static int createUser(User user) throws SQLException {
		int rowAddedCount = 0;
		conn = new DBConnector();
		rowAddedCount = conn.createUser(user);
		return rowAddedCount;
	}
	
	public static void removeUser(int id) throws SQLException {
		conn = new DBConnector();
		conn.removeUser(id);
	}
	
	public static int updateUser(User new_user) throws SQLException {
		int idUser = 0;
		conn = new DBConnector();
		idUser = conn.updateUser(new_user);
		return idUser;
	}
}
