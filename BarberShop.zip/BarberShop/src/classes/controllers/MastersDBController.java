package classes.controllers;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import classes.DBConnector;
import classes.Masters;
import classes.Operations;

public class MastersDBController {
	public static List<Masters> getMastersList(){
		List<Masters> masters = new ArrayList<>();
		try {
			DBConnector conn = new DBConnector();
			masters = conn.getMastersList();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return masters;
		
	}
}
