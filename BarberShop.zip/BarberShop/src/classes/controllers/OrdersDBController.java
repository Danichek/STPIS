package classes.controllers;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import classes.DBConnector;
import classes.Orders;

public class OrdersDBController {

	
	public static List<Orders> getOrdersListByUserId(int user_id){
		
		List<Orders> userOrders = new ArrayList<>();
		try {
			DBConnector conn = new DBConnector();
			userOrders = conn.getUserOrdersList(user_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userOrders;
	}
	
	public static int createOrder(Orders order){
		int addedRowCount = 0;
		try {
			DBConnector conn = new DBConnector();
			addedRowCount = conn.createOrder(order);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return addedRowCount;
	}

	public static int deleteUserOrder(int orderId) {
		int rowDeletedCount = 0;
		try {
			DBConnector conn = new DBConnector();
			rowDeletedCount = conn.deleteUserOrder(orderId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rowDeletedCount;
	}
}
