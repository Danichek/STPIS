package classes.controllers;

import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;

import classes.DBConnector;
import classes.Operations;

public class OptionsDBController {

	
	public static List<Operations> getOptionsList(){
		
		List<Operations> userOperations = new ArrayList<>();
		try {
			DBConnector conn = new DBConnector();
			userOperations = conn.getOptionsList();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userOperations;
	}
}
