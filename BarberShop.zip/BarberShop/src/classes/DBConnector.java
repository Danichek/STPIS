package classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.lang.reflect.InvocationTargetException;
import java.sql.*;

import com.mysql.cj.jdbc.Driver;

public class DBConnector {
	String url = "jdbc:mysql://localhost/barbershop?useSSL=false";
    String username = "daniil";
    String password = "danik.15";
    Connection conn = null;
    
    public DBConnector() throws SQLException{
    	//    	if(driver == null) driver = new Driver();
//    	if(conn == null) conn = DriverManager.getConnection(url, username, password);
//    	 Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
    }
    // USER FUNCTIONS PART START //
    
    public List<User> getAllUsers() throws SQLException {
    	 try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
			try(Connection conn = DriverManager.getConnection(url, username, password)){
		   	
	    	List<User> users = new ArrayList<>();
	    	Statement statement = conn.createStatement();
	    	ResultSet resSet = statement.executeQuery("select * from barbershop.users");
	    	while(resSet.next()) {
	    		int id = resSet.getInt(1);
	    		String user_login = resSet.getString(2);
	    		String user_pass = resSet.getString(3);
	    		String user_name = resSet.getString(4);
	    		String user_surname = resSet.getString(5);
	    		String user_middlename = resSet.getString(6);
	    		String user_email = resSet.getString(7) != null? resSet.getString(7) : "";
	    		String user_phone = resSet.getString(8) != null? resSet.getString(8) : "";
	    		User user = new User(id, user_login, user_pass, user_name, user_surname, user_middlename, user_email, user_phone);
	    		users.add(user);
	    	}
	    	return users;
	    	}
    	 
    	 } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    	
    }
    
	public User getUserByLogin(String login) throws SQLException {
    	User user = null;
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try(Connection conn = DriverManager.getConnection(url, username, password)){
				String sql = "select * from barbershop.users where login = '" + login + "'";
				try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
					ResultSet resSet = preparedStatement.executeQuery();
					while(resSet.next()) {
			    		int id = resSet.getInt(1);
			    		String user_login = resSet.getString(2);
			    		String user_pass = resSet.getString(3);
			    		String user_name = resSet.getString(4);
			    		String user_surname = resSet.getString(5);
			    		String user_middlename = resSet.getString(6);
			    		String user_email = resSet.getString(7) != null? resSet.getString(7) : "";
			    		String user_phone = resSet.getString(8) != null? resSet.getString(8) : "";
			    		user = new User(id, user_login, user_pass, user_name, user_surname, user_middlename, user_phone, user_email);
			    	}
			    	return user;
		    	}
				catch(Exception e) {
					System.out.println("1");
					System.out.println(e.getMessage());
				}
	    	}
			catch(SQLException e) {
				System.out.println("2");
				System.out.println(e.getMessage());
			}
    	}catch (IllegalArgumentException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
    		System.out.println(e.getMessage());
		}
    	return user;
    }
	
	public int getUserIdByLogin(String login) throws SQLException {
    	User user = null;
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try(Connection conn = DriverManager.getConnection(url, username, password)){
				String sql = "select id from barbershop.users where login = '" + login + "'";
				try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
					ResultSet resSet = preparedStatement.executeQuery();
					int id = -1;
					while(resSet.next()) {
			    		id = resSet.getInt(1);
					}
			    	return id;
		    	}
				catch(Exception e) {
					System.out.println("1");
					System.out.println(e.getMessage());
				}
	    	}
			catch(SQLException e) {
				System.out.println("2");
				System.out.println(e.getMessage());
			}
    	}catch (IllegalArgumentException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
    		System.out.println(e.getMessage());
		}
    	return -1;
    }
    
    public boolean isUserPresent(String login) {
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try(Connection conn = DriverManager.getConnection(url, username, password)){
				String sql = "SELECT count(id) FROM barbershop.users WHERE login='"+login+"'";
				try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
					ResultSet resSet = preparedStatement.executeQuery();
					boolean isExist = true;
					if(resSet.next()) {
						isExist = resSet.getInt(1)>0;
					}
			    	resSet.close();
			    	return isExist;
		    	}
				catch(Exception e) {
					System.out.println("1");
					System.out.println(e.getMessage());
				}
	    	}
			catch(SQLException e) {
				System.out.println("2");
				System.out.println(e.getMessage());
			}
    	} catch (IllegalArgumentException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
    		System.out.println(e.getMessage());
		}
    	
		return true;
    }
    
    public void removeUser(int id) throws SQLException {
    	Statement statement = conn.createStatement();
    	statement.executeQuery("DELETE from barbershop.users where id = "+id);	
    	return;
    }
    
    public int createUser(User user) throws SQLException {
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try(Connection conn = DriverManager.getConnection(url, username, password)){
				
//				Statement statement = conn.createStatement();
				String sql = "INSERT INTO barbershop.users "
		    			+ "(login, password, userName, userSurname, userMiddlename, userEmail, userPhone ) "
		    			+ "VALUES ('"+user.getLogin()+"', '" +user.getPassword()+"', '" + user.getUserName()+ "', '"
		    			+user.getUserSurname()+"', '"+user.getUserMiddlename()+"', '" + user.getUserEmail() +"', '" 
		    			+ user.getUserPhone() + "');";
				try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
					return  preparedStatement.executeUpdate();
				}
				catch(Exception e) {
					System.out.println("1");
					System.out.println(e.getMessage());
				};
	    	}
			catch(SQLException e) {
				System.out.println("2");
				System.out.println(e.getMessage());
			}
    	}catch (IllegalArgumentException | SecurityException | ClassNotFoundException e) {
    		System.out.println(e.getMessage());
		}
    	return 0;
    }
    
    public int updateUser(User new_user) throws SQLException {
    	Statement statement = conn.createStatement();
    	statement.executeQuery("UPDATE barbershop.users SET "
    			+ "login = '" + new_user.getUserEmail()+ ", "
    			+ "password= '" + new_user.getUserEmail()+ ", "
    			+ "userName= '" + new_user.getUserEmail()+ ", "
    			+ "userSurname= '" + new_user.getUserEmail()+ ", "
    			+ "userMiddlename = '"+ new_user.getUserMiddlename()+", "
    			+ "userEmail = '" + new_user.getUserEmail()+ ","
    			+ "userPhone = '" + new_user.getUserEmail()+","
    			+ "WHERE (id = " + new_user.getId() + ");");	
    	return new_user.getId();
    }

    // USER FUNCTIONS PART END //
    
    
    // OPTION FUNCTIONS PART START //
    
    public List<Operations> getOptionsList() throws SQLException {
   	 try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
			try(Connection conn = DriverManager.getConnection(url, username, password)){
		   	
	    	List<Operations> options = new ArrayList<>();
	    	Statement statement = conn.createStatement();
	    	ResultSet resSet = statement.executeQuery("select * from barbershop.options");
	    	while(resSet.next()) {
	    		int id = resSet.getInt(1);
	    		String option_Name = resSet.getString(2);
	    		long option_price = resSet.getLong(3);
	    		Operations option = new Operations(id, option_Name, option_price);
	    		options.add(option);
	    	}
	    	return options;
	    }
   	 
   	 } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
   	
   }

   
    // OPTION FUNCTIONS PART END //
    
    
    // MASTERS FUNCTIONS PART START //
    public List<Masters> getMastersList() throws SQLException {
      	 try {
   			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
   			try(Connection conn = DriverManager.getConnection(url, username, password)){
	   	    	List<Masters> masters = new ArrayList<>();
	   	    	Statement statement = conn.createStatement();
	   	    	ResultSet resSet = statement.executeQuery("select * from barbershop.master");
	   	    	while(resSet.next()) {
	   	    		int id = resSet.getInt(1);
	   	    		String master_Name = resSet.getString(2);
	   	    		String master_Surname = resSet.getString(3);
	   	    		String master_Middlename = resSet.getString(4);
	   	    		Masters master = new Masters(id, master_Name, master_Surname, master_Middlename);
	   	    		masters.add(master);
	   	    	}
	   	    	return masters;
	   	    }
      	 } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
   				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
   		return null;
      	
      }
    // MASTERS FUNCTIONS PART END //
    
    
    
    // ORDERS FUNCTIONS PART START //
		public List<Orders> getUserOrdersList(int user_id)throws SQLException {
			// TODO Auto-generated method stub
			try {
	   			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
	   			try(Connection conn = DriverManager.getConnection(url, username, password)){
	   		   	
	   				String sql = "SELECT uo.id_orders,"
	   						+ "  m.mastername, m.mastersurname,"
	   						+ "  o.optionsname,"
	   						+ "  uo.order_date"
	   						+ " FROM "
	   						+ " barbershop.user_orders uo,"
	   						+ " barbershop.users u,"
	   						+ " barbershop.master m,"
	   						+ " barbershop.options o "
	   						+ "where u.id=uo.userID "
	   						+ "and m.id_master=uo.masterid "
	   						+ "and o.id_options=uo.optionsid "
	   						+ "and u.id="+user_id;
		   	    	List<Orders> orders = new ArrayList<>();
		   	    	Statement statement = conn.createStatement();
		   	    	ResultSet resSet = statement.executeQuery(sql);
		   	    	while(resSet.next()) {
		   	    		int order_id = resSet.getInt(1);
		   	    		String masterName = resSet.getString(2);
		   	    		String masterSurname = resSet.getString(3);
		   	    		String serviceName = resSet.getString(4);
		   	    		String date = resSet.getString(5);
		   	    		String ordersDate = date.split("T")[0] + " " + date.split("T")[1];
		   	    		Orders order = new Orders(order_id, masterName, masterSurname, serviceName, ordersDate);
		   	    		orders.add(order);
		   	    	}
		   	    	return orders;
		   	    }
	      	 
	      	 } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
	   				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
	   			// TODO Auto-generated catch block
	   			e.printStackTrace();
	   		}
			return null;
		}
		
		public int createOrder(Orders order) throws SQLException {
	    	try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				try(Connection conn = DriverManager.getConnection(url, username, password)){
					
//					Statement statement = conn.createStatement();
					String sql = "INSERT INTO barbershop.user_orders "
			    			+ "(userId, masterId, optionsId, order_date) "
			    			+ "VALUES ('"+order.getUser_id()+"', '" +order.getMaster_id()+"', '" + order.getOperation_id()+ "', '"
			    			+order.getOrderDate()+"');";
					try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
						return  preparedStatement.executeUpdate();
					}
					catch(Exception e) {
						System.out.println("createOrder 1");
						System.out.println(e.getMessage());
					};
		    	}
				catch(SQLException e) {
					System.out.println("createOrder 2");
					System.out.println(e.getMessage());
				}
	    	}catch (IllegalArgumentException | SecurityException | ClassNotFoundException e) {
				System.out.println("createOrder 3");
	    		System.out.println(e.getMessage());
			}
	    	return 0;
	    }
    // ORDERS FUNCTIONS PART END //

		public int deleteUserOrder(int orderId) {
			// TODO Auto-generated method stub
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				try(Connection conn = DriverManager.getConnection(url, username, password)){
					
//					Statement statement = conn.createStatement();
					String sql = "delete from barbershop.user_orders where id_orders="+orderId;
					 try(PreparedStatement preparedStatement = conn.prepareStatement(sql)){
		                      
		                    return  preparedStatement.executeUpdate();
		                }
		    	}
				catch(SQLException e) {
					System.out.println("2");
					System.out.println(e.getMessage());
				}
	    	}catch (IllegalArgumentException | SecurityException | ClassNotFoundException e) {
	    		System.out.println(e.getMessage());
			}
			return 0;
		}
}
