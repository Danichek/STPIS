package test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import org.junit.Test;
import classes.controllers.*;
import classes.*;

public class OptionsDBControllerTestingClass {
	@Test 
	public void getOrdersListTest() throws SQLException
	{
		System.out.println("Starting test " + new Object(){}.getClass().getEnclosingMethod().getName());
		assertEquals(10, OptionsDBController.getOptionsList().size());	 
		System.out.println("Ending test " + new Object(){}.getClass().getEnclosingMethod().getName());
	}
}
