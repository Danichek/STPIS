package test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import org.junit.Test;
import classes.controllers.*;
import classes.*;

public class MastersDBControllerTestingClass {
	@Test 
	public void getMastersListTest() throws SQLException
	{
		System.out.println("Starting test " + new Object(){}.getClass().getEnclosingMethod().getName());
		assertEquals(6, MastersDBController.getMastersList().size());	 
		System.out.println("Ending test " + new Object(){}.getClass().getEnclosingMethod().getName());
	}
}
