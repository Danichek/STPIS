package test;

import static org.junit.Assert.*;
import java.sql.SQLException;
import org.junit.Test;
import classes.controllers.*;
import classes.*;

public class UserDBControllerTestingClass {
	@Test 
	public void registrationTest()
	{
		System.out.println("Starting test " + new Object(){}.getClass().getEnclosingMethod().getName());
		User user = new User("userForTest","test","UserTestName","UserTestSurname","UserTestMiddlename","testUser@testUser.email","");
		try {
			assertEquals(1, UserDBController.createUser(user));
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}	 
		System.out.println("Ending test " + new Object(){}.getClass().getEnclosingMethod().getName());
	}
}
