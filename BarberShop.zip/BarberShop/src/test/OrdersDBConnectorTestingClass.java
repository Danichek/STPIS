package test;

import static org.junit.Assert.*;
import java.sql.SQLException;
import org.junit.Test;
import classes.controllers.*;
import classes.*;

public class OrdersDBConnectorTestingClass {
	@Test 
	public void createOrderTest() throws SQLException
	{
		System.out.println("Starting test " + new Object(){}.getClass().getEnclosingMethod().getName());
		Orders order = new Orders(2, 1, 2, "2021-10-10T10:30");
		assertEquals(1, OrdersDBController.createOrder(order));	 
		System.out.println("Ending test " + new Object(){}.getClass().getEnclosingMethod().getName());
	}
	
	@Test 
	public void getOrdersListTest() throws SQLException
	{
		System.out.println("Starting test " + new Object(){}.getClass().getEnclosingMethod().getName());
		assertEquals(2, OrdersDBController.getOrdersListByUserId(2).size());	 
		System.out.println("Ending test " + new Object(){}.getClass().getEnclosingMethod().getName());
	}
	
	@Test 
	public void removeUserOrderTest() throws SQLException
	{
		System.out.println("Starting test " + new Object(){}.getClass().getEnclosingMethod().getName());
		assertEquals(1, OrdersDBController.deleteUserOrder(2));	 
		System.out.println("Ending test " + new Object(){}.getClass().getEnclosingMethod().getName());
	}
}
